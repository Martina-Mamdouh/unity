﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class que2 : MonoBehaviour {

    public List<Button> answerButtons; // قائمة الأزرار
    public TextMeshProUGUI scoreText; // نص عرض النتيجة
    public Image correctImage; // صورة الإجابة الصحيحة
    public Image wrongImage; // صورة الإجابة الخاطئة
    public Color correctColor = Color.green; // لون الإجابة الصحيحة
    public Color wrongColor = Color.red; // لون الإجابة الخاطئة
    public AudioSource audioSource; // مصدر الصوت
    public AudioClip correctAudio; // صوت الإجابة الصحيحة
    public AudioClip wrongAudio; // صوت الإجابة الخاطئة
    private bool isAnswered = false;
    public AudioClip warningAudio;
    public Button correctButton; // الزر الصحيح
    private int score = 0; // النقاط

    // تحديد الإجابة الصحيحة
    public void SetCorrectAnswer(Button button)
    {
        correctButton = button; // تحديد الزر الصحيح
    }

    // التحقق من الإجابة
    public void CheckAnswer(Button selectedButton)
    {
        // تعطيل جميع الأزرار بعد الإجابة
        foreach (Button btn in answerButtons)
        {
            btn.interactable = false;
        }

        if (selectedButton == correctButton)
        {
            // إذا كانت الإجابة صحيحة
            selectedButton.GetComponent<Image>().color = correctColor;
            correctImage.gameObject.SetActive(true); // أظهر الصورة الصحيحة
            audioSource.PlayOneShot(correctAudio); // شغل الصوت الصحيح
            score += 10; // زود النقاط
            UpdateScore(); // حدث النقاط
            Invoke("HideFeedback", 2f);
            isAnswered = true;
            // أخفِ الصورة بعد ثانيتين
        }
        else
        {
            // إذا كانت الإجابة خاطئة
            selectedButton.GetComponent<Image>().color = wrongColor;
            wrongImage.gameObject.SetActive(true); // أظهر صورة الإجابة الخاطئة
            audioSource.PlayOneShot(wrongAudio); // شغل الصوت الخاطئ
            Invoke("HideFeedback", 2f);
            correctButton.GetComponent<Image>().color = correctColor;
            isAnswered = true;
            // أظهر الإجابة الصحيحة
        }
    }

    // تحديث النقاط
    void UpdateScore()
    {
        scoreText.text = "Score: " + score;
        PlayerPrefs.SetInt("Score", score); // حفظ النقاط في PlayerPrefs
    }

    // إخفاء الصور وإعادة تعيين الألوان
    void HideFeedback()
    {
        correctImage.gameObject.SetActive(false);
        wrongImage.gameObject.SetActive(false);
        ResetButtonColors();
    }

    // إعادة لون الأزرار للأبيض
    void ResetButtonColors()
    {
        foreach (Button btn in answerButtons)
        {
            btn.GetComponent<Image>().color = Color.white;
        }
    }

    // إعادة تفعيل الأزرار
    public void EnableButtons()
    {
        foreach (Button btn in answerButtons)
        {
            btn.interactable = true;
        }
    }

    // إعادة تعيين كل شيء للسؤال التالي
    public void LoadNextQuestion()
    {
        HideFeedback();
        EnableButtons();
    }

    // استرجاع النقاط عند بدء المشهد
    public void Start()
    {
        score = PlayerPrefs.GetInt("Score", 0); // استرجاع النقاط من PlayerPrefs
        UpdateScore(); // تحديث النص لعرض النقاط
    }

    // الانتقال إلى السؤال التالي
    public void GoToNextQuestion()
    {
        if (isAnswered) // التحقق إذا كانت الإجابة قد تم اختيارها
        {
            // تحميل المشهد التالي (الكويز التالي)
            SceneManager.LoadScene("ques3");
        }

        else
        {
            audioSource.PlayOneShot(warningAudio);

        } // تحميل المشهد التالي
    }
}
