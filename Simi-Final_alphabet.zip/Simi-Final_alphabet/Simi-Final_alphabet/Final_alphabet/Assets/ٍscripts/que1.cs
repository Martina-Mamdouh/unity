﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class que1 : MonoBehaviour {

    public List<Button> answerButtons; // قائمة الأزرار
    public TextMeshProUGUI scoreText; // نص عرض النتيجة
    public Image correctImage; // صورة الإجابة الصحيحة
    public Image wrongImage; // صورة الإجابة الخاطئة
    public Color correctColor = Color.green; // لون الإجابة الصحيحة
    public Color wrongColor = Color.red; // لون الإجابة الخاطئة
    public AudioSource audioSource; // مصدر الصوت
    public AudioClip correctAudio; // صوت الإجابة الصحيحة
    public AudioClip wrongAudio; // صوت الإجابة الخاطئة
    public AudioClip warningAudio; // صوت التحذير
    public Button correctButton; // الزر الصحيح
    private bool isAnswered = false; // التأكد من الإجابة
    private int score = 0; // النقاط

    private void Start()
    {
        // إعادة تعيين النقاط إذا كنت في المشهد الأول
        if (SceneManager.GetActiveScene().name == "ques1") // افترض أن اسم المشهد الأول هو "q1"
        {
            score = 0;
            PlayerPrefs.SetInt("Score", 0); // تصفير النقاط
            PlayerPrefs.Save();
        }
        else
        {
            // استرجاع النقاط من الجلسة السابقة
            score = PlayerPrefs.GetInt("Score", 0);
        }

        UpdateScore(); // تحديث عرض النقاط
    }

    // تحديد الإجابة الصحيحة
    public void SetCorrectAnswer(Button button)
    {
        correctButton = button; // تحديد الزر الصحيح
    }

    // التحقق من الإجابة
    public void CheckAnswer(Button selectedButton)
    {
        if (isAnswered) return; // منع الإجابة أكثر من مرة

        isAnswered = true;

        // تعطيل جميع الأزرار بعد الإجابة
        foreach (Button btn in answerButtons)
        {
            btn.interactable = false;
        }

        if (selectedButton == correctButton)
        {
            // إذا كانت الإجابة صحيحة
            selectedButton.GetComponent<Image>().color = correctColor;
            correctImage.gameObject.SetActive(true); // أظهر الصورة الصحيحة
            audioSource.PlayOneShot(correctAudio); // شغل الصوت الصحيح
            score += 10; // زود النقاط فقط إذا كانت الإجابة صحيحة
            UpdateScore(); // حدث النقاط
        }
        else
        {
            // إذا كانت الإجابة خاطئة
            selectedButton.GetComponent<Image>().color = wrongColor;
            wrongImage.gameObject.SetActive(true); // أظهر صورة الإجابة الخاطئة
            audioSource.PlayOneShot(wrongAudio); // شغل الصوت الخاطئ
            correctButton.GetComponent<Image>().color = correctColor; // أظهر الإجابة الصحيحة
        }

        // إخفاء الصور بعد ثانيتين
        Invoke("HideFeedback", 2f);
    }

    // تحديث النقاط
    void UpdateScore()
    {
        scoreText.text = "Score: " + score;
        PlayerPrefs.SetInt("Score", score); // حفظ النقاط
        PlayerPrefs.Save();
    }

    // إخفاء الصور وإعادة تعيين الألوان
    void HideFeedback()
    {
        correctImage.gameObject.SetActive(false);
        wrongImage.gameObject.SetActive(false);
        ResetButtonColors();
    }

    // إعادة لون الأزرار للأبيض
    void ResetButtonColors()
    {
        foreach (Button btn in answerButtons)
        {
            btn.GetComponent<Image>().color = Color.white;
        }
    }

    // إعادة تفعيل الأزرار
    public void EnableButtons()
    {
        foreach (Button btn in answerButtons)
        {
            btn.interactable = true;
        }
    }

    // تحميل السؤال التالي
    public void GoToNextQuestion()
    {
        if (isAnswered) // التحقق إذا كانت الإجابة قد تم اختيارها
        {
            // تحميل المشهد التالي
            SceneManager.LoadScene("ques2");
        }
        else
        {
            // تشغيل صوت التحذير
            audioSource.PlayOneShot(warningAudio);
        }
    }
}
