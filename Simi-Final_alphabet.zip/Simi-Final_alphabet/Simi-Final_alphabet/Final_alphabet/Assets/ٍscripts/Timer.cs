﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Timer : MonoBehaviour {

    public static Timer instance;
    public float quizTime = 20f;
    private bool timerStarted = false;
    public TextMeshProUGUI timerText;
    private int score = 0; // النقاط التي سيتم تخزينها

    public void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject); // لتبقى الكائنات موجودة بين المشاهد
        }
        else
        {
            Destroy(gameObject);
        }

        LoadScore(); // تحميل النقاط عند بدء اللعبة
    }

    public void Update()
    {
        if (timerStarted)
        {
            quizTime -= Time.deltaTime;

            if (quizTime <= 0)
            {
                quizTime = 0;
                timerStarted = false;
                UpdateTimerDisplay();
                GoToTimeUpScene(); // الانتقال إلى مشهد "TimeUp" عند انتهاء الوقت
                return;
            }

            if (timerText != null)
            {
                UpdateTimerDisplay();
            }
        }
    }

    public void StartTimerAndGoToQuestions()
    {
        timerStarted = true;
        SceneManager.LoadScene("ques1"); // الانتقال إلى مشهد الأسئلة
    }

    public void UpdateTimerDisplay()
    {
        int minutes = Mathf.FloorToInt(quizTime / 60);
        int seconds = Mathf.FloorToInt(quizTime % 60);
        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    public void GoToTimeUpScene()
    {
        // تخزين النقاط في PlayerPrefs قبل الانتقال إلى مشهد "TimeUp"
        //PlayerPrefs.SetInt("Score", score);
        //PlayerPrefs.Save(); // حفظ النقاط بشكل دائم
        Debug.Log("Saved Score before TimeUp scene: " + score);
        Destroy(gameObject);
        SceneManager.LoadScene("TimeUp - quiz2");
    }

    public void UpdateScore(int newScore)
    {
        score = newScore;
        PlayerPrefs.SetInt("Score", score); // حفظ النقاط الجديدة
        PlayerPrefs.Save(); // حفظ النقاط بشكل دائم
    }

    public void LoadScore()
    {
        score = PlayerPrefs.GetInt("Score", 0); // تحميل النقاط من PlayerPrefs (إذا كانت موجودة)
    }

    public void OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, LoadSceneMode mode)
    {
        GameObject timerObject = GameObject.Find("Time");
        if (timerObject != null)
        {
            timerText = timerObject.GetComponent<TextMeshProUGUI>();
        }
    }

    public void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    public void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }
}
