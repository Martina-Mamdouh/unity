﻿using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class RetryScript : MonoBehaviour
{
    // لعرض النقاط
    public TextMeshProUGUI scoreText;  // لعرض النسبة المئوية

    private void Start()
    {
        // استرجاع النقاط المخزنة
        int score = PlayerPrefs.GetInt("Score", 0);  // استرجاع النقاط المخزنة
        Destroy(GameObject.Find("QuizTimer"));
        // عرض النتيجة والنسبة المئوية في النصوص
        scoreText.text = "Score: " + score.ToString();
        //scoreText.text = "Total Score: " + score;
    }

    // دالة لإعادة المشهد الأول عند الضغط على زر إعادة المحاولة
    public void ReplayQuiz()
    {
        // تصفير النقاط
        PlayerPrefs.SetInt("Score", 0);
        PlayerPrefs.Save();

        // تحميل مشهد الأسئلة
        SceneManager.LoadScene("Play"); // افترض أن اسم مشهد الأسئلة هو "q1"
    }
}

