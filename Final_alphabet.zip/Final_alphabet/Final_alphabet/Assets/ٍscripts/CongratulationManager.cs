﻿using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class CongratulationManager : MonoBehaviour
{

    public TextMeshProUGUI scoreText; // لعرض النسبة المئوية
    /*   public TextMeshProUGUI congratulationMessage; */ // لعرض رسالة التهنئة

    private void Start()
    {
        int score = PlayerPrefs.GetInt("Score", 0);  // استرجاع النقاط المخزنة

        // عرض النتيجة والنسبة المئوية في النصوص
        scoreText.text = "Score: " + score.ToString();

        Destroy(GameObject.Find("QuizTimer"));


        //// عرض رسالة التهنئة إذا كانت النتيجة 70% أو أعلى
        //if (percentage >= 70)
        //{
        //    congratulationMessage.text = "Congratulations! You passed with great success!";
        //}
        //else
        //{
        //    congratulationMessage.text = "Good try! Keep practicing!";
        //}
    }

    // دالة للانتقال إلى مشهد الأسئلة إذا أراد اللاعب إعادة المحاولة
    public void GoToMainMenu()
    {
        SceneManager.LoadScene("SampleScene"); // انتقل إلى الشاشة الرئيسية أو شاشة البداية
    }
}
