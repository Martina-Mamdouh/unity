﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class GoToQuiz : MonoBehaviour {

	public void GoToAlphabet()
	{
		SceneManager.LoadScene("Play");
	}
    public void GoToNumbers()
    {
        SceneManager.LoadScene("play2");
    }
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
