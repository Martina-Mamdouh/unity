﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.SocialPlatforms.Impl;

public class Result : MonoBehaviour {

    // Use this for initialization
    public void OnArrowClicked()
    {
        // استرجاع النقاط من PlayerPrefs
        int score = PlayerPrefs.GetInt("Score", 0);
        Debug.Log("Retrieved Score: " + score);  // تأكيد النقاط التي تم استرجاعها
        // التحقق من النقاط والانتقال للمشهد المناسب
        if (score >= 30)
        {
            SceneManager.LoadScene("congratulation");
        }
        else
        {
            SceneManager.LoadScene("retry");
        }
    }
        void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
